#!/bin/sh
echo 'Executando makemigrations.sh'
python manage.py makemigrations --noinput
