#!/bin/sh
python manage.py collectstatic --noinput
